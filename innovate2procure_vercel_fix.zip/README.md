# Innovate2Procure

A startup-friendly innovation procurement prototype for government departments.

## Vercel deployment

This project uses Python + Flask. Vercel can run the Flask application from `app.py`.

### Important database note

The prototype uses SQLite. On Vercel, the database is placed in `/tmp` because the deployed filesystem is not persistent. This is suitable for a demo/prototype, but submitted users may not persist reliably between serverless instances.

For a real deployment, replace SQLite with a hosted production database such as PostgreSQL and add proper authentication.

## Local run

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Vercel

After replacing `app.py` in the GitHub repository, push to `main`. Vercel should automatically create a new deployment.

## Prototype security note

This is a college-project prototype. The Host/Admin role is currently selected through the demo login form. Before collecting real personal or government data, use proper authentication, password hashing or SSO, HTTPS, protected admin roles, a production database, audit logging, privacy/retention controls and security review.
